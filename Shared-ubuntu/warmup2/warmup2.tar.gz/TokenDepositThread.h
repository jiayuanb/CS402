#ifndef _TOKENDEPOSITTHREAD_H_
#define _TOKENDEPOSITTHREAD_H_

#include "Packet.h"

extern void * TokenDepositThread(void * arg);

#endif