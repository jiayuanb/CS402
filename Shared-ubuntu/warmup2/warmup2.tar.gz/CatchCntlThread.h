#ifndef _CATCHCNTLTHREAD_H_
#define _CATCHCNTLTHREAD_H_

#include "my402list.h"

extern void * CatchCntlThread(void *arg);

#endif