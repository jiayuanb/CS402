#ifndef _SERVERTHREAD_H_
#define _SERVERTHREAD_H_

extern void * ServerThread(void * arg);

#endif