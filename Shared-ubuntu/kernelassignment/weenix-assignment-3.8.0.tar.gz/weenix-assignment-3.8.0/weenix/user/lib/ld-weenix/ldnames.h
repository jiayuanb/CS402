/*
 *  File: ldnames.h
 *  Date: 30 March 1998
 *  Acct: David Powell (dep)
 *  Desc:
 */

#ifndef _ldnames_h_
#define _ldnames_h_

#ifdef  __cplusplus
extern "C" {
#endif


        void _ldaddname(const char *name);
        int _ldchkname(const char *name);


#ifdef  __cplusplus
}
#endif

#endif /* _ldnames_h_ */

